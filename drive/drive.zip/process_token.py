import json
import pickle

# 读取 token.json
with open('token.json', 'r') as f:
    data = json.load(f)

# 写入为 token.pkl
with open('token.pkl', 'wb') as f:
    pickle.dump(data, f)


with open('desk-credentials.json', 'r') as f:
    data = json.load(f)

# 写入为 token.pkl
with open('desk-credentials.pkl', 'wb') as f:
    pickle.dump(data, f)